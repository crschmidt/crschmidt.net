#!/usr/bin/python
import sys, re 
import RDF
import urllib
import xml.dom.minidom as minidom
API_KEY="7fbed205a8e56220ab8877e1a11d0671"
def get_rdf(id):
    id = str(id)
    m = RDF.Model()
    p = RDF.Parser()
    url = "http://www.kanzaki.com/works/2005/imgdsc/flickr2rdf?%s" % urllib.urlencode({"u": "http://flickr.com/photos/crschmidt/%s/" % id })
    u = urllib.urlopen(url)
    data = u.read()
    data = data.replace(".jpg", "_o.jpg")
    data = data.replace("_o_o.jpg", "_o.jpg")
    p.parse_string_into_model(m, data, "http://crschmidt.net/albums/flickr/%s" % id)
    s = m.find_statements(RDF.Statement(None, RDF.Uri("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), RDF.Uri("http://xmlns.com/foaf/0.1/Image")))
    photo = s.current().subject
    photo = photo.uri
    uri = photo
    url = "http://www.kanzaki.com/test/exif2rdf?%s" % urllib.urlencode({"u":uri})
    u = urllib.urlopen(url)
    data = u.read()
    data = re.sub('<!--(?:[^-]+|-(?!-))+-->', '', data)
    p.parse_string_into_model(m, data, "http://crschmidt.net/albums/flickr/%s" % id)
    url = "http://www.flickr.com/services/rest/?method=flickr.photos.getSizes&api_key=%s&photo_id=%s" % (API_KEY, id)
    u = urllib.urlopen(url)
    doc = minidom.parseString(u.read())
    photoSize = {}
    sizes = doc.getElementsByTagName("size")
    for i in sizes:
        photoSize[i.attributes.get("label").value] = (i.attributes.get("width").value, i.attributes.get("height").value)
    ratio = ((float(photoSize['Original'][0])/float(photoSize['Medium'][0]) + float(photoSize['Original'][1])/float(photoSize['Medium'][1])) / 2)
    addlist = []
    dellist = []
    for i in m.find_statements(RDF.Statement(None,RDF.Uri("http://www.w3.org/2004/02/image-regions#coords"), None)):
        coords = i.object.literal_value['string']
        topleft, bottomright = coords.split(" ")
        a, b = topleft.split(",")
        topleft = "%s,%s" % (int(int(a)*ratio), int(int(b)*ratio))
        a, b = bottomright.split(",")
        bottomright = "%s,%s" % (int(int(a)*ratio), int(int(b)*ratio))
        s = RDF.Statement(i.subject, i.predicate, RDF.Node("%s %s" % (topleft, bottomright)))
        addlist.append(s)
        dellist.append(i)
    for i in addlist:
    	m.append(s)
    for i in dellist:
    	del m[i]
    
    statements = m.find_statements(RDF.Statement(None, RDF.Uri("http://xmlns.com/foaf/0.1/topic"), RDF.Uri("http://www.flickr.com/photos/tags/geotagged/")))
    if statements.current():
        geo = {}
        url = "http://www.flickr.com/services/rest/?method=flickr.tags.getListPhoto&api_key=%s&photo_id=%s" % (API_KEY, id)
        u = urllib.urlopen(url)
        doc = minidom.parseString(u.read())
        tags = doc.getElementsByTagName("tag")
        m.append(RDF.Statement(RDF.Uri(photo), RDF.Uri("http://purl.org/dc/terms/spatial"), RDF.Uri("http://crschmidt.net/flickr/%s#location" % id)))
        for i in tags:
            v = i.attributes.get("raw").value
            if (v.startswith("geo") and ("=" in v)):
                v = v[4:]
                lhs, rhs = v.split("=")
                if lhs == "lon": lhs = "long"
                url = "http://crschmidt.net/flickr/%s#location" % id
                p = "http://www.w3.org/2003/01/geo/wgs84_pos#%s" % lhs
                m.append(RDF.Statement(RDF.Uri(str(url)), RDF.Uri(str(p)), RDF.Node(str(rhs))))
    s = RDF.RDFXMLSerializer()
    s.set_namespace("foaf", "http://xmlns.com/foaf/0.1/")
    s.set_namespace("dc", "http://purl.org/dc/elements/1.1/")
    s.set_namespace("rdfs", "http://www.w3.org/2000/01/rdf-schema#")
    s.set_namespace("whois", "http://www.kanzaki.com/ns/whois#")
    s.set_namespace("imgreg", "http://www.w3.org/2004/02/image-regions#")
    s.set_namespace("image", "http://jibbering.com/vocabs/image/#")
    s.set_namespace("exif", "http://www.kanzaki.com/ns/exif#")
    s.set_namespace("geo", "http://www.w3.org/2003/01/geo/wgs84_pos#")
    s.set_namespace("dcterms", "http://purl.org/dc/terms/")
    print "%s done." % id
    s.serialize_model_to_file("flickr/%s" % id,m)
if __name__ == "__main__":   
   get_rdf(sys.argv[1]) 
