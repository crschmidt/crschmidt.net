import urllib
import xml.dom.minidom as minidom
import flickr2rdf
API_KEY="7fbed205a8e56220ab8877e1a11d0671"

u = urllib.urlopen("http://flickr.com/services/rest/?method=flickr.people.getPublicPhotos&api_key=%s&user_id=56541240@N00&per_page=500" % API_KEY)
photolist = u.read()
u.close()
doc = minidom.parseString(photolist)
photos = doc.getElementsByTagName("photo")
for photo in photos:
    id = photo.getAttributeNode("id").value
    flickr2rdf.get_rdf(id)
    #u = urllib.urlopen("http://flickr.com/services/rest/?method=flickr.photos.getInfo&api_key=%s&photo_id=%s" % (API_KEY, id))
    #print u.read()
